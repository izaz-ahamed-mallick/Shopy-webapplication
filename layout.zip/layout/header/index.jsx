import Link from "next/link";

const Header = () => {
    return (
        <header className="bg-indigo-600">
            <div className="container w-full mx-auto flex items-center justify-between p-4">
                <div className="text-white text-lg font-bold">
                    <Link href="/" legacyBehavior>
                        <a>MyApp</a>
                    </Link>
                </div>
                <nav className="flex space-x-4">
                    <Link href="/" legacyBehavior>
                        <a className="text-white hover:text-gray-200">Home</a>
                    </Link>
                    <Link href="/auth/login" legacyBehavior>
                        <a className="text-white hover:text-gray-200">Login</a>
                    </Link>
                    <Link href="/auth/registration" legacyBehavior>
                        <a className="text-white hover:text-gray-200">
                            Register
                        </a>
                    </Link>
                </nav>
            </div>
        </header>
    );
};

export default Header;
