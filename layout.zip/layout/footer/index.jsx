import Link from "next/link";

const Footer = () => {
    return (
        <footer className="bg-indigo-600">
            <div className="container mx-auto flex items-center justify-between p-4">
                <div className="text-white text-sm">
                    © {new Date().getFullYear()} MyApp. All rights reserved.
                </div>
                <div className="flex space-x-4">
                    <Link
                        href="/privacy-policy"
                        className="text-white hover:text-gray-200"
                    >
                        Privacy Policy
                    </Link>
                    <Link
                        href="/terms-of-service"
                        className="text-white hover:text-gray-200"
                    >
                        Terms of Service
                    </Link>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
