import Wrapper from "@/layout/wrapper/Wrapper";
import "@/styles/globals.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const queryClient = new QueryClient();

export default function App({ Component, pageProps }) {
    return (
        <div>
            <QueryClientProvider client={queryClient}>
                <Wrapper>
                    <Component {...pageProps} />
                </Wrapper>
            </QueryClientProvider>
        </div>
    );
}
