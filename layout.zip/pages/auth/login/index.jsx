import { login } from "@/api/functions/login.api";
import { useSignInMutation } from "@/hooks/customHooks/authQuery.hooks";
import {
    Button,
    Container,
    Grid,
    Paper,
    TextField,
    Typography,
} from "@mui/material";

import { useForm } from "react-hook-form";

const Login = () => {
    const {
        handleSubmit,
        register,
        formState: { errors },
    } = useForm();

    const { mutate } = useSignInMutation();

    const onSubmit = (data) => mutate(data);
    return (
        <Container>
            <Grid container spacing={2}>
                <Grid item xs={12} md={6} sx={{ margin: "0 auto" }}>
                    <Paper elevation={3} sx={{ padding: 2 }}>
                        <Typography variant="h5" gutterBottom>
                            Contact Form
                        </Typography>
                        <form>
                            <TextField
                                {...register("email", {
                                    required: "Email is required",
                                    pattern: {
                                        value: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
                                        message: "Invalid email format",
                                    },
                                })}
                                label="Your Email"
                                fullWidth
                                margin="normal"
                                variant="outlined"
                                error={errors.email}
                                helperText={
                                    errors.email && errors.email.message
                                }
                            />
                            <TextField
                                {...register("password", { required: true })}
                                label="password"
                                fullWidth
                                margin="normal"
                                variant="outlined"
                                multiline
                                rows={4}
                                error={!!errors.password}
                                helperText={
                                    errors.password && "Password is required"
                                }
                            />

                            <Button
                                variant="contained"
                                color="primary"
                                fullWidth
                                size="large"
                                type="submit"
                                onClick={handleSubmit(onSubmit)}
                                sx={{ marginTop: 2 }}
                            >
                                Send Message
                            </Button>
                        </form>
                    </Paper>
                </Grid>
            </Grid>
        </Container>
    );
};

export default Login;
