import Image from "next/image";
import { Inter } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });

export default function Home() {
    return (
        <div>
            <main className="flex items-center justify-center min-h-screen bg-gray-100">
                <h1 className="text-4xl font-bold">Welcome to NextJs</h1>
            </main>
        </div>
    );
}
