import { login } from "@/api/functions/login.api";
import { Cookies } from "react-cookie";
import { useGlobalHooks } from "../globalHooks/globalHooks";
import { useMutation } from "@tanstack/react-query";

export const useSignInMutation = () => {
    const cookie = new Cookies();
    const { queryClient } = useGlobalHooks();
    return useMutation({
        mutationFn: login,
        onSuccess: (response) => {
            const {
                token,
                status,
                message,
                data: { first_name },
            } = response || {};
            if (status === 200) {
                cookie.set("token", token);
                cookie.set("first_name", first_name);

                toast(message, "success");
            } else {
                toast(message, "error");
            }
            queryClient.invalidateQueries({ queryKey: ["USERS"] });
        },
    });
};
