export const endPoints = {
    auth: {
        signIn: "/user/signin",
        signUp: "/user/signup",
    },
};
export const endPointsPath = [endPoints.auth.signIn, endPoints.auth.signUp];
